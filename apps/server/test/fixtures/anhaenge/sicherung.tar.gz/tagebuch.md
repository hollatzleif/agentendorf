Tagebuch im Tar-Archiv
